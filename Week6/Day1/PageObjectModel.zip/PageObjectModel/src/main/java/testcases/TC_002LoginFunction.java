package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002LoginFunction extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="Login";

	}

	@Test(dataProvider="fetchData")
	public void runLogin(String uName, String PWord) {
		LoginPage lp=new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(PWord)
		.clickLoginButton();
   }

} 
//                             filename
//@BeforeTest @BeforeMethod   @DataProvider @Test  @AfterMethod
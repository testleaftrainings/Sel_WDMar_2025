package testcases;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
               // //data[0][0]="TestLeaf";
	                             //      EditLead
	public static String[][] read(String filename) throws IOException {
		
		//Open the Workbook
		XSSFWorkbook wb=new XSSFWorkbook("./Data/"+filename+".xlsx");
		
		//Open the Worksheet
		//XSSFSheet ws = wb.getSheet("Sheet1");
        XSSFSheet ws = wb.getSheetAt(0);
		
		//To count the number of rows
		//Without header
		int rowCount = ws.getLastRowNum();
		System.out.println("Row count is : "+rowCount);
		
		//With header
		int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
		System.out.println("Including header: "+physicalNumberOfRows);
		
		
		//To count the number of column
		int columnCount = ws.getRow(1).getLastCellNum();
		System.out.println("Column Count is: "+columnCount);
		
		//Retrieve the data
		String stringAtRow1Cell1 = ws.getRow(1).getCell(1).getStringCellValue();
		System.out.println("Row1Cell1 data is: "+stringAtRow1Cell1);
		
		
		String[][] data= new String[rowCount][columnCount];
		
		
		//To retrieve a entire data
		//          1    2
		for (int i = 1; i <= rowCount; i++) {
			XSSFRow row = ws.getRow(i);   //getRow(1)
			//    0   1    2   
			for (int j = 0; j < columnCount; j++) {
				String allData = row.getCell(j).getStringCellValue();
				System.out.println(allData);
				data[i-1][j]=allData;
				
				//data[0][0]="TestLeaf";
				//data[0][1]="Vineeth";
				//data[0][2]="Rajendran"
				
				
				//data[1][0]="Qeagle";
				//data[1][1]="Hari";
				//data[1][2]="R"
				
				//getRow(1).getCell(0).getStringCellValue() - TestLeaf
				//getRow(1).getCell(1).getStringCellValue() - Vineeth
				//getRow(1).getCell(2).getStringCellValue() - Rajendran
				
				//getRow(2).getCell(0).getStringCellValue() - Qeagle
				//getRow(2).getCell(1).getStringCellValue() - Hari
				//getRow(2).getCell(2).getStringCellValue() - R
			}
			
		}
		wb.close();
		return data;
	}

}

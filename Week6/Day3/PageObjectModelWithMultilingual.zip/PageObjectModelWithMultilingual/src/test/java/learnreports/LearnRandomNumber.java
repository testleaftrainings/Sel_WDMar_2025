package learnreports;

public class LearnRandomNumber {

	public static void main(String[] args) {
		//double randomNumber = Math.random();
		//System.out.println(randomNumber);
		
		
		int randomNumber=(int)(Math.random()*9999999+99999999);
		System.out.println(randomNumber);
		

	}

}
//image0.5864309502925281     image34455666666
//0.817384969913299
package base;

import java.io.IOException;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{
	//public static EdgeDriver driver;
	private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
	
	public void setDriver() {
		driver.set(new EdgeDriver());

	}
	
	public EdgeDriver getDriver()   {
		EdgeDriver edgeDriver = driver.get();
		return edgeDriver;

	}
	
	public String filename;
	@BeforeMethod
	public void preConditions() {
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/login");
}
	
	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] readData() throws IOException {
		
		String[][] read = ReadExcel.read(filename);   //Login
		return read;
		}
	}

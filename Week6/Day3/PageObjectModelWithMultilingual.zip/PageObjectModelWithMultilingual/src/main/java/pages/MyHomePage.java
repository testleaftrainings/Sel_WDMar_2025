package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;

public class MyHomePage extends BaseClass {
	@And("Click on the Leads link")
	public MyLeadsPage clickLeadsLink() {
		String propertyOfleads = prop.getProperty("clickleads");
		getDriver().findElement(By.linkText(propertyOfleads)).click();
         return new MyLeadsPage();
	}

}

package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001CreateLeadFunction extends BaseClass{

	@Test
	public void runCreateLead() {
		LoginPage lp=new LoginPage();
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyname()
		.enterFirstname()
		.enterLastname()
		.clickCreateLeadButton()
		.verifyLead();

	}
	
	
}

package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;

public class CreateLeadPage extends BaseClass {
	
	@And("Enter the companyname as (.*)$")
	public CreateLeadPage enterCompanyname(String companyName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
        return this;
	}
	
	@And("Enter the Firstname as (.*)$")
	public CreateLeadPage enterFirstname(String firstName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
        return this;
	}
	
	@And("Enter the lastname as (.*)$")
	public CreateLeadPage enterLastname(String lastName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
        return this;
	}
	
	@And("Click on the CreateLead button")
	public ViewLeadPage clickCreateLeadButton() {
		getDriver().findElement(By.name("submitButton")).click();
        return new ViewLeadPage();
	}

}

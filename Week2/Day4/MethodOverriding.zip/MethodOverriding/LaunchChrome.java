package week2.day4;

import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchChrome {
	
	
	public void launchBrowser() {
		ChromeDriver driver=new ChromeDriver();
		System.out.println("Chrome is launched");

	}
	


}

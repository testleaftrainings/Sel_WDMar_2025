package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.BaseClass;
import io.cucumber.java.en.And;

public class MyLeadsPage extends BaseClass {
	
	@And("Click on the CreateLead link")
	public CreateLeadPage clickCreateLeadLink() {
		String propertyOfCreatelead = prop.getProperty("clickcreatelead");
		WebElement findElement =getDriver().findElement(By.partialLinkText(propertyOfCreatelead));
		findElement.click();
        return new CreateLeadPage();
	}

}

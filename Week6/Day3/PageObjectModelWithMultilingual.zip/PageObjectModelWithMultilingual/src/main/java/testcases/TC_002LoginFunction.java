package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002LoginFunction extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="Login";
		testName="Login Function";
		testDescription="Login with Valid credentials";
		testAuthor="Hari";
		testCategory="Smoke";

	}

	@Test(dataProvider="fetchData")
	public void runLogin(String uName, String PWord) throws IOException {
		LoginPage lp=new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(PWord)
		.clickLoginButton();
   }

} 
//                             filename
//@BeforeTest @BeforeMethod   @DataProvider @Test  @AfterMethod
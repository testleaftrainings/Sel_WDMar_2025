package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{
	//public static EdgeDriver driver;
	private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
	
	public static ExtentReports extent;
	
	public static String testName,testDescription,testAuthor,testCategory;
	
	public static ExtentTest test;
	
	public static Properties prop;
	
	
	public void setDriver() {
		driver.set(new EdgeDriver());

	}
	
	public EdgeDriver getDriver()   {
		EdgeDriver edgeDriver = driver.get();
		return edgeDriver;

	}
	
	public String filename;
	@BeforeSuite
	public void startReport() {
		
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/Login.html");
				extent=new ExtentReports();
				extent.attachReporter(reporter);

	}
	
	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	
	                     
	public void reportStep(String status, String message) throws IOException {
	if (status.equals("Pass")) {
		test.pass(message, MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/image"+takeSnap()+".png").build());
	}                                                                                 
	else if(status.equals("fail")) {
		test.fail(message);
	}

	}
	
	public int takeSnap() throws IOException {
		
		int randomNumber=(int)(Math.random()*9999999+99999999);
		System.out.println(randomNumber);
		
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		
		File destination=new File("./Snaps/image"+randomNumber+".png");
		
		//image12345
		//image23456
		
		FileUtils.copyFile(source, destination);
		
		return randomNumber;

	}
	
	
	
	
	
	
	
	
	
	
	
	
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}
	
	
	
	
	@BeforeMethod
	public void preConditions() throws IOException {
		       
				FileInputStream fis=new FileInputStream("src/test/resources/french.properties");
				
	           prop=new Properties();
				
				prop.load(fis);
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/login");
}
	
	@AfterMethod
	public void postConditions() {
		getDriver().close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] readData() throws IOException {
		
		String[][] read = ReadExcel.read(filename);   //Login
		return read;
		}
	}

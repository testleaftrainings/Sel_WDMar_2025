package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.BaseClass;

public class MyLeadsPage extends BaseClass {
	
	public CreateLeadPage clickCreateLeadLink() {
		WebElement findElement = driver.findElement(By.linkText("Create Lead"));
		findElement.click();
        return new CreateLeadPage();
	}

}

package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001CreateLeadFunction extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		filename="CreateLead";
		testName="Createlead Function";
		testDescription="Create Lead with multiple data";
		testAuthor="Vineeth";
		testCategory="Regression";

	}

	@Test(dataProvider="fetchData")
	public void runCreateLead(String uName,String pWord,String companyName, String firstName,String lastName) throws IOException {
		LoginPage lp=new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.clickCRMSFA()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyname(companyName)
		.enterFirstname(firstName)
		.enterLastname(lastName)
		.clickCreateLeadButton()
		.verifyLead();

	}
	
	
}

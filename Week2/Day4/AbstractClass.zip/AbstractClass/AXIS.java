package week2.day4;

public abstract class AXIS implements RBI {
	
	public void houseLoan() {
		System.out.println("Upto 50 Lakhs");
		}
	
    public abstract void carLoan();
  }

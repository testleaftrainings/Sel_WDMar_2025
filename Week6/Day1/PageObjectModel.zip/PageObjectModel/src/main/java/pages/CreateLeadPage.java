package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class CreateLeadPage extends BaseClass {
	
	public CreateLeadPage enterCompanyname(String companyName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
        return this;
	}
	
	
	public CreateLeadPage enterFirstname(String firstName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
        return this;
	}
	
	
	public CreateLeadPage enterLastname(String lastName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
        return this;
	}
	
	
	public ViewLeadPage clickCreateLeadButton() {
		driver.findElement(By.name("submitButton")).click();
        return new ViewLeadPage();
	}

}

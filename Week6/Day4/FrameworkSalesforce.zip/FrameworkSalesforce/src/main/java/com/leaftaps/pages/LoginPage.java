package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	
	public LoginPage enterUsername(String uName) {
		clearAndType(locateElement(Locators.ID, "username"), uName);
         return this;
	}
	
	public LoginPage enterPassword(String pWord) {
		clearAndType(locateElement("password"), pWord);
        return this;
	}
	
	
	public void clickLogin() {
		click(Locators.ID, "Login");

	}

}

package learnpropertyfile;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LearnProperty {

	public static void main(String[] args) throws IOException {
		//Step1: Locate the path
		FileInputStream fis=new FileInputStream("src/test/resources/eng.properties");
		
		//Step2:
		Properties prop=new Properties();
		
		//Step3:
		prop.load(fis);
		
		//To retrieve the data
		String valueOfUsername = prop.getProperty("username");
		
		System.out.println("The username is: "+valueOfUsername);
		
		//To retrieve the password
		String valueOfPassword = prop.getProperty("password");
		System.out.println("The password is: "+valueOfPassword);
	}

}

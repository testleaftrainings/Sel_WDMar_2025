package learnreports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) {
		// Step1: Set up the path
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/Login.html");
		
		//Step2: Create a Test
		ExtentReports extent=new ExtentReports();
		
		//Step3: Adding the test to the output
		extent.attachReporter(reporter);
		
		//Step4: Create a Testcase
		ExtentTest test = extent.createTest("Login", "Login with valid credentials");
		
		//Step5: Adding the status
		test.pass("Username entered successfully");
		test.pass("Password entered successfuly");
		test.pass("Login button is clicked");
		
		//To Close the report
		extent.flush();
		
		System.out.println("Completed");
	}

}

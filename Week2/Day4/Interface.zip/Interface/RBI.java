package week2.day4;


public interface RBI {
	
    public void mandatoryKyc();
	
	public void depositAmount();
	

}




package pages;

import base.BaseClass;
import io.cucumber.java.en.And;

public class ViewLeadPage extends BaseClass {
	
	@And("Lead should be created")
	public void verifyLead() {
		System.out.println("Lead is Created");

	}

}
